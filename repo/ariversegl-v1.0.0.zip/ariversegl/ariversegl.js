
function getPopularManga(page) {
  return [
    {
      title: "Demo Manga 1",
      url: "https://ariversegl.com/manga/demo-1",
      thumbnail: "https://ariversegl.com/assets/thumb1.jpg"
    },
    {
      title: "Demo Manga 2",
      url: "https://ariversegl.com/manga/demo-2",
      thumbnail: "https://ariversegl.com/assets/thumb2.jpg"
    }
  ];
}

function getMangaDetails(url) {
  return {
    title: "Demo Manga 1",
    author: "Tác giả A",
    artist: "Họa sĩ A",
    description: "Đây là mô tả của truyện Demo Manga 1.",
    genres: ["Hành động", "Giả tưởng"],
    status: "Đang phát hành"
  };
}

function getChapterList(url) {
  return [
    {
      name: "Chapter 1",
      url: url + "/chapter-1",
      number: 1
    },
    {
      name: "Chapter 2",
      url: url + "/chapter-2",
      number: 2
    }
  ];
}

function getPageList(chapterUrl) {
  return [
    {
      url: "https://ariversegl.com/assets/page1.jpg"
    },
    {
      url: "https://ariversegl.com/assets/page2.jpg"
    }
  ];
}
